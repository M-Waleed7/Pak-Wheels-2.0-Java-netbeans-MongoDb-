/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pak.wheels.project;

import javax.swing.JOptionPane;

/**
 *
 * @author wwwwa
 */
public class Sign_info extends Person {
    private String username;
    private String password;
    private String cnic;
    private String email;
    private String country;
    private String city;
    Sign_info(){
        super();
        username="";
        cnic="";
        email="";
        country="";
        city="";
        password="";
    }

    public Sign_info(String name,String number,String address, String cnic, String email, String country, String city, String username, String password ) {
        super(name, number,address);
        this.cnic = cnic;
        this.email = email;
        this.country = country;
        this.city = city;
        this.username = username;
        this.password = password;
    }
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getCnic() {
        return cnic;
    }

    public void setCnic(String cnic) {
        this.cnic = cnic;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
  public boolean checkCnic(){

        int i = 0;
        int check=1;
        while(cnic.length() !=13 || i !=cnic.length()){
            char x = cnic.charAt(i);
            i++;
            if(!(Character.isDigit(x))) {
              i = 0;
              check=0;
              break;
            }
            if(cnic.length() !=13){
              check=0;
              break;
                }
            else 
                check=1;
        
       }
        if (check==1){
            return true;
        }
        else
            return false;
  }
  
       
}
