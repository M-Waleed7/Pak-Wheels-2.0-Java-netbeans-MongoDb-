/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pak.wheels.project;

/**
 *
 * @author wwwwa
 */
public class Screen_Runner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Screen obj = new Screen();
       obj.setVisible(true);
       try{
           for (int a =0;a<=100;a++){
               Thread.sleep(59);
           obj.p1.setValue(a);
           
           if(a==100){
            obj.setVisible(false);
            new Login().setVisible(true);
           }
           }
       }
       catch(Exception e){
           
       }
    }
    
}
