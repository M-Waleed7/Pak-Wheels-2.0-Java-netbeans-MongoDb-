/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pak.wheels.project;

/**
 *
 * @author Aleks
 */
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MapReduceCommand;
import com.mongodb.MapReduceOutput;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;
import com.mongodb.client.MapReduceIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import java.text.ParseException;
import java.util.Collection;

import java.util.Date;

public class MongoMain {

    //Creating a Mongo client and creating/retrieving the database
    MongoClient mongoClient = new MongoClient();
    MongoDatabase db = mongoClient.getDatabase("PakWheels");

    public static void main(String args[]) {

    }

    
    //This method enables the user to insert a new gamer/user to the forum
    public void insertLogin(String username,String password,String name,String cnic, String email, String country ,String city, String address, String number) throws ParseException {
        db.getCollection("Login");
        db.getCollection("Login").insertOne(
                new Document()
                .append("username", username)
                .append("password", password)
                 .append("name", name)
                 .append("cnic", cnic)
                .append("email", email)
                .append("country", country)
                .append("city", city)
                .append("address", address)
                .append("number", number));
        
    }
 public static boolean validateLogin(String username, String password) {
        MongoClient mongoClient = new MongoClient(new ServerAddress("localhost", 27017));
        MongoDatabase database = mongoClient.getDatabase("PakWheels");
        MongoCollection<Document> collection = database.getCollection("Login");

        Document query = new Document("username", username)
                .append("password", password);
        Document result = collection.find(query).first();
        mongoClient.close();
        return result != null;
    }
 public void insertcar(String company,String carname,String model, String price, String name ,String number, String address) throws ParseException {
        db.getCollection("Cars");
        db.getCollection("Cars").insertOne(
                new Document()
                .append("company", company)
                .append("carname", carname)
                 .append("model", model)
                 .append("price", price)
                .append("name", name)
                .append("address", address)
                .append("number", number));
        
    }
  public void insertBookcar(String collection,String company,String carname,String model, String price) throws ParseException {
        db.getCollection(collection);
        db.getCollection(collection).insertOne(
                new Document()
                .append("company", company)
                .append("carname", carname)
                 .append("model", model)
                 .append("price/hour", price)
);
        
    }

    public void updatePass(String username, String newpass) {
        db.getCollection("Login").updateOne(new Document("username", username),
                new Document("$set", new Document("password", newpass)));
    }

    public void deleteUser(String name) {
        db.getCollection("users").deleteMany(new Document("name", name));
    }

  

}
