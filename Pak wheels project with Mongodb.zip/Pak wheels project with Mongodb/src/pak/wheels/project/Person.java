/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pak.wheels.project;

/**
 *
 * @author wwwwa
 */
public class Person {
    private String name;
    private String address;
    private String  number;
    
    public Person(){
        name="";
        number="";
        address="";    }
    public Person(String name ,String number,String address) {
        this.name = name;
        
        this.number = number;
        this.address=address;
    }
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    

    

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    public boolean checknumber() {
        int i = 0;
        int check=1;
        while (number.length() != 11 || i != number.length()) {
            char x = number.charAt(i);
            i++;
            if (!(Character.isDigit(x))) {
              i = 0;
              check=0;
              break;
            }

            if (number.length() != 11) {
            
            check=0;
              break;
        }}
       if (check==1){
            return true;
        }
        else
            return false;
  }
    public boolean checkstring(String temp){
        int check=1;
        for (int x=0;x<temp.length();x++){
        char t = temp.charAt(x);
        if (!Character.isAlphabetic(t)){
            check=0;
            break;
        }
                }
        if (check==1){
            return true;
            
        }
        else 
            return false;
    }
    public boolean checkinteger(String temp){
    int check=1;
        for (int x=0;x<temp.length();x++){
        char t = temp.charAt(x);
        if (!Character.isDigit(t)){
            check=0;
            break;
        }
                }
        if (check==1){
            return true;
            
        }
        else 
            return false;
    }
   
    }
    

 
